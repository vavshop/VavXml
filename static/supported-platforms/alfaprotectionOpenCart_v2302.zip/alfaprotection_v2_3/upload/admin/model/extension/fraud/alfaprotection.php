<?php
class ModelExtensionFraudAlfaProtection extends Model {
	public function install() {
		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "alfaprotection` (
			  `fraud_id` int(11) NOT NULL,
			  `order_id` int(11) NOT NULL,
			  `error` varchar(255) NOT NULL,
			  `error_message` text,
			  `id` varchar(255) NOT NULL,
			  `funds_remaining` int(11) NOT NULL,
			  `queries_remaining` int(11) NOT NULL,
			  `risk_score` decimal(15,2) NOT NULL,
			  `ip_risk` decimal(15,2) NOT NULL,
			  `status` varchar(255) NOT NULL,
			  `status_messages` text NOT NULL,
			  `billing_is_in_ip_country` int(2) NOT NULL,
			  `billing_longitude` decimal(15,9) NOT NULL,
			  `billing_is_postal_in_city` int(2) NOT NULL,
			  `billing_latitude` decimal(15,9) NOT NULL,
			  `billing_distance_to_ip_location` int(11) NOT NULL,
			  `shop_longitude` decimal(15,9) NOT NULL,
			  `shop_is_high_risk` int(2) NOT NULL,
			  `shop_distance_to_billing_address` int(11) NOT NULL,
			  `shop_is_postal_in_city` int(2) NOT NULL,
			  `shop_latitude` decimal(15,9) NOT NULL,
			  `shop_is_in_ip_country` int(2) NOT NULL,
			  `shop_distance_to_ip_location` int(11) NOT NULL,
			  `user_is_high_risk` int(2) NOT NULL,
			  `user_actis_freeion` int(2) NOT NULL,
			  `card_is_issued_in_billing_address_country` int(2) NOT NULL,
			  `card_country` varchar(255) NOT NULL,
			  `card_issuer_matches_provided_phone_number` int(2) NOT NULL,
			  `card_issuer_matches_provided_name` int(2) NOT NULL,
			  `card_issuer_name` varchar(255) NOT NULL,
			  `card_issuer_phone_number` varchar(15) NOT NULL,
			  `card_is_prepaid` int(2) NOT NULL,
			  `customer_id` int(11) NOT NULL,
			  `ip_address_location_latitude` decimal(15,9) NOT NULL,
			  `ip_address_location_longitude` decimal(15,9) NOT NULL,
			  `ip_address_location_accuracy_radius` int(11) NOT NULL,
			  `ip_address_location_time_zone` varchar(255) NOT NULL,
			  `ip_address_location_local_time` varchar(255) NOT NULL,
			  `ip_address_traits_is_legitimate_proxy` int(2) NOT NULL,
			  `ip_address_traits_is_satellite_provider` int(2) NOT NULL,
			  `ip_address_traits_ip_address` varchar(40) NOT NULL,
			  `ip_address_traits_isp` varchar(255) NOT NULL,
			  `ip_address_traits_is_anonymous_proxy` int(2) NOT NULL,
			  `ip_address_traits_organization` varchar(255) NOT NULL,
			  `ip_address_traits_autonomous_system_organization` varchar(255) NOT NULL,
			  `ip_address_traits_user_type` varchar(255) NOT NULL,
			  `ip_address_traits_autonomous_system_number` int(11) NOT NULL,
			  `ip_address_traits_domain` varchar(255) NOT NULL,
			  `ip_address_country_geoname_id` int(11) NOT NULL,
			  `ip_address_country_name` varchar(255) NOT NULL,
			  `ip_address_country_confidence` int(11) NOT NULL,
			  `ip_address_country_is_high_risk` int(2) NOT NULL,
			  `ip_address_country_names` text NOT NULL,
			  `ip_address_country_iso_code` varchar(3) NOT NULL,
			  `ip_address_risk` decimal(15,2) NOT NULL,
			  `ip_address_subdivisions_geoname_id` int(11) NOT NULL,
			  `ip_address_subdivisions_name` varchar(255) NOT NULL,
			  `ip_address_subdivisions_iso_code` int(3) NOT NULL,
			  `ip_address_subdivisions_confidence` int(11) NOT NULL,
			  `ip_address_subdivisions_names` text NOT NULL,
			  `ip_address_registered_country_is_high_risk` int(2) NOT NULL,
			  `ip_address_registered_country_geoname_id` int(11) NOT NULL,
			  `ip_address_registered_country_name` varchar(255) NOT NULL,
			  `ip_address_registered_country_iso_code` varchar(2) NOT NULL,
			  `ip_address_registered_country_names` text NOT NULL,
			  `ip_address_city_geoname_id` int(11) NOT NULL,
			  `ip_address_city_name` varchar(255) NOT NULL,
			  `ip_address_city_confidence` int(11) NOT NULL,
			  `ip_address_city_names` text NOT NULL,
			  `ip_address_continent_geoname_id` int(11) NOT NULL,
			  `ip_address_continent_name` varchar(255) NOT NULL,
			  `ip_address_continent_confidence` int(11) NOT NULL,
			  `ip_address_continent_names` text NOT NULL
			) ENGINE=MyISAM DEFAULT CHARSET=utf8;
		");

		$this->db->query("INSERT INTO " . DB_PREFIX . "order_status SET name = 'Approved', language_id = '" . (int)$this->config->get('config_language_id') . "'");
		$this->db->query("INSERT INTO " . DB_PREFIX . "order_status SET name = 'Manual check', language_id = '" . (int)$this->config->get('config_language_id') . "'");
		$this->db->query("INSERT INTO " . DB_PREFIX . "order_status SET name = 'Decline', language_id = '" . (int)$this->config->get('config_language_id') . "'");

	}

	public function uninstall() {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "alfaprotection`");
		$this->db->query("DELETE FROM `" . DB_PREFIX . "order_status` WHERE name = 'Approved'");
		$this->db->query("DELETE FROM `" . DB_PREFIX . "order_status` WHERE name = 'Manual check'");
		$this->db->query("DELETE FROM `" . DB_PREFIX . "order_status` WHERE name = 'Decline'");
	}

	public function getOrder($order_id) {
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "alfaprotection` WHERE order_id = '" . (int)$order_id . "'");

		return $query->row;
	}
}