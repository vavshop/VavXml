<?php
class ModelFraudalfaprotection extends Model {
	public function check($order_info) {
		$risk_score = 0;
		/*
		alfaprotection api
		https://alfaprotection.com/protect/info/api/
		*/

		$ips = array();

		$ips['browser'] = array(
			'ip' => $order_info['ip'],
			'user_agent' => $order_info['user_agent'],
			'language' => $order_info['accept_language'],
		);

		$ips['shop'] = array(
			'id' => $order_info['store_id'],
			'event' => 'purchase',
			'transaction' => 'txn3134133',
			 'datetime' => date('Y-m-d\TH:i:s\Z', strtotime($order_info['date_added'])),
		);

		$ips['user'] = array(
			'id' =>  $order_info['ip'],
			'name_md5' => md5($order_info['firstname'].' '.$order_info['lastname']),
			'email' => $order_info['email'],
		//	'domain' => str_replace('http://', $order_info['store_url']),
		);

		$query_billing_country = $this->db->query("SELECT * FROM " . DB_PREFIX . "country WHERE country_id = '" . (int)$order_info['payment_country_id'] . "' AND status = '1'");
		$billing_country = $query_billing_country->row['iso_code_2'];

		$query_billing_region = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone WHERE zone_id = '" . (int)$order_info['payment_zone_id'] . "' AND status = '1'");
		$billing_region = $query_billing_region->row['code'];

		$ips['billing'] = array(
			'first_name' => $order_info['payment_firstname'],
			'last_name' => $order_info['payment_lastname'],
			'company' => $order_info['payment_company'],
			'address' => $order_info['payment_address_1'],
			'address_2' => $order_info['payment_address_2'],
			'city' => $order_info['payment_city'],
			'region' => $billing_region,
			'country' => $billing_country,
			'postal' => $order_info['payment_postcode'],
			'phone' => $order_info['telephone'],
			'country_code' => $order_info['payment_country_id'],
		);

		$query_selling_country = $this->db->query("SELECT * FROM " . DB_PREFIX . "country WHERE country_id = '" . (int)$order_info['payment_country_id'] . "' AND status = '1'");
		$selling_country = $query_selling_country->row['iso_code_2'];

		$query_selling_region = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone WHERE zone_id = '" . (int)$order_info['payment_zone_id'] . "' AND status = '1'");
		$selling_region = $query_selling_region->row['code'];

		$ips['selling'] = array(
			'first_name' => $order_info['shipping_firstname'],
			'last_name' => $order_info['shipping_lastname'],
			'company' => $order_info['shipping_company'],
			'address' => $order_info['shipping_address_1'],
			'address_2' => $order_info['shipping_address_2'],
			'city' => $order_info['shipping_city'],
			'region' => $selling_region,
			'country' => $selling_country,
			'postal' => $order_info['shipping_postcode'],
			'phone' => $order_info['telephone'],
			'country_code' => $order_info['shipping_country_id'],
			'delivery_speed' => 'standard',
		);

		// $ips['card'] = array(
		// 	'country_code' => '',
		// 	'phone' => '',
		// 	'last_digits' => '',
		// 	'cvv_result' => '',
		// 	'id_issuer' => '',
		// 	'avs_result' => '',
		// );

		// $ips['payment'] = array(
		// 	'decline_code' => '',
		// 	'was_authorized' => '',
		// 	'processor' => 'other',
		// );

		$query_product = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_info['order_id']. "'");
		$products = $query_product->rows;

		foreach ($products as $product) {
			$ips['shopping_card'][] = array(
			'category' => $product['model'],
			'quantity' => $product['quantity'],
			'price' => $product['price'],
			'item_id' => $product['name'],
			);
		}

		$ips['order'] = array(
			'amount' => $order_info['total'],
			'order_id' => $order_info['order_id'],
			'currency' => $order_info['currency_code'],
			'discount_code' => $order_info['commission'],
			// 'affiliate_id' => '',
			// 'subaffiliate_id' => '',
			'referrer_uri' => $order_info['store_url'],
			'is_gift' => true,
			'has_gift_message' => false,
		);

	  $ips['secret'] = $this->config->get('alfaprotection_key');
		$ips['user_id'] = $order_info['customer_id'];

		$curl = curl_init();

		curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8'));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_URL, 'https://alfaprotection.com/protect/api/riskfactor/');
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($ips));

		$result = curl_exec($curl);

		curl_close($curl);

		$info = array();

		$info['secret'] = $this->config->get('alfaprotection_key');

		$data_response = json_decode($result, true);
		$info['id'] = $data_response['id'];

		$ch = curl_init();

		// curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, 'https://alfaprotection.com/protect/api/get_info/');
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $info);

		$inormation = curl_exec($ch);
		$response = json_decode($inormation, true);
		curl_close($ch);

		$error = ($data_response['error'] == 0 ? 'false': 'true');

		if ($error == 'false') {

			$order_id = $order_info['order_id'];
			$id = $data_response['id'];
			$status = $data_response['status'];
			if ($status == 'approved') {
				$status_messages = '';
			} else {
				$status_messages = json_encode($data_response['status_messages']);
			}

			if (isset($response['funds_remaining'])) {
				$funds_remaining = $response['funds_remaining'];
			} else {
				$funds_remaining = '';
			}

			if (isset($response['queries_remaining'])) {
				$queries_remaining = $response['queries_remaining'];
			} else {
				$queries_remaining = '';
			}

			if (isset($data_response['risk_score'])) {
				$risk_score = $data_response['risk_score'];
			} else {
				$risk_score = '';
			}

			if (isset($response['billing']['is_in_ip_country']) && $response['billing']['is_in_ip_country'] == true) {
				$billing_is_in_ip_country = 1;
			} else {
				$billing_is_in_ip_country = 0;
			}

			if (isset($response['billing']['longitude'])) {
				$billing_longitude = $response['billing']['longitude'];
			} else {
				$billing_longitude = '';
			}

			if (isset($response['billing']['is_postal_in_city']) && $response['billing']['is_postal_in_city'] == true) {
				$billing_is_postal_in_city = 1;
			} else {
				$billing_is_postal_in_city = 0;
			}

			if (isset($response['billing']['latitude'])) {
				$billing_latitude = $response['billing']['latitude'];
			} else {
				$billing_latitude = '';
			}

			if (isset($response['billing']['distance_to_ip_location'])) {
				$billing_distance_to_ip_location = $response['billing']['distance_to_ip_location'];
			} else {
				$billing_distance_to_ip_location = '';
			}

			if (isset($response['shop']['longitude'])) {
				$shop_longitude = $response['shop']['longitude'];
			} else {
				$shop_longitude = '';
			}

			if (isset($response['shop']['is_high_risk']) && $response['shop']['is_high_risk'] == true) {
				$shop_is_high_risk = 1;
			} else {
				$shop_is_high_risk = 0;
			}

			if (isset($response['shop']['distance_to_billing_address'])) {
				$shop_distance_to_billing_address = $response['shop']['distance_to_billing_address'];
			} else {
				$shop_distance_to_billing_address = '';
			}

			if (isset($response['shop']['is_postal_in_city']) && $response['shop']['is_postal_in_city'] == true) {
				$shop_is_postal_in_city = 1;
			} else {
				$shop_is_postal_in_city = 0;
			}

			if (isset($response['shop']['latitude'])) {
				$shop_latitude = $response['shop']['latitude'];
			} else {
				$shop_latitude = '';
			}

			if (isset($response['shop']['is_in_ip_country']) && $response['shop']['is_in_ip_country'] == true) {
				$shop_is_in_ip_country = 1;
			} else {
				$shop_is_in_ip_country = 0;
			}

			if (isset($response['shop']['distance_to_ip_location'])) {
				$shop_distance_to_ip_location = $response['shop']['distance_to_ip_location'];
			} else {
				$shop_distance_to_ip_location = '';
			}

			if (isset($response['user']['is_high_risk']) && $response['user']['is_high_risk'] == true) {
				$user_is_high_risk = 1;
			} else {
				$user_is_high_risk = 0;
			}

			if (isset($response['user']['actis_freeion'])) {
				$user_actis_freeion = $response['user']['actis_freeion'];
			} else {
				$user_actis_freeion = '';
			}

			if (isset($response['card']['is_issued_in_billing_address_country']) && $response['card']['is_issued_in_billing_address_country'] == true) {
				$card_is_issued_in_billing_address_country = 1;
			} else {
				$card_is_issued_in_billing_address_country = 0;
			}

			if (isset($response['card']['country'])) {
				$card_country = $response['card']['country'];
			} else {
				$card_country = '';
			}

			if (isset($response['card']['issuer']['matches_provided_phone_number'])) {
				$card_issuer_matches_provided_phone_number = $response['card']['issuer']['matches_provided_phone_number'];
			} else {
				$card_issuer_matches_provided_phone_number = '';
			}

			if (isset($response['card']['issuer']['matches_provided_name'])) {
				$card_issuer_matches_provided_name = str_replace("'", "\'", $response['card']['issuer']['matches_provided_name']);
			} else {
				$card_issuer_matches_provided_name = '';
			}

			if (isset($response['card']['issuer']['name'])) {
				$card_issuer_name = str_replace("'", "\'", $response['card']['issuer']['name']);
			} else {
				$card_issuer_name = '';
			}

			if (isset($response['card']['issuer']['phone_number'])) {
				$card_issuer_phone_number = $response['card']['issuer']['phone_number'];
			} else {
				$card_issuer_phone_number = '';
			}

			if (isset($response['ip_address']['registered_country']['is_high_risk']) && $response['ip_address']['registered_country']['is_high_risk'] == true) {
				$ip_address_registered_country_is_high_risk = 1;
			} else {
				$ip_address_registered_country_is_high_risk = 0;
			}

			if (isset($response['ip_address']['registered_country']['geoname_id'])) {
				$ip_address_registered_country_geoname_id = $response['ip_address']['registered_country']['geoname_id'];
			} else {
				$ip_address_registered_country_geoname_id = '';
			}

			if (isset($response['ip_address']['registered_country']['name'])) {
				$ip_address_registered_country_name = str_replace("'", "\'", $response['ip_address']['registered_country']['name']);
			} else {
				$ip_address_registered_country_name = '';
			}

			if (isset($response['ip_address']['registered_country']['iso_code'])) {
				$ip_address_registered_country_iso_code = $response['ip_address']['registered_country']['iso_code'];
			} else {
				$ip_address_registered_country_iso_code = '';
			}

			if (isset($response['ip_address']['registered_country']['names'])) {
				$ip_address_registered_country_names = str_replace("'", "\'", $response['ip_address']['registered_country']['names']);
			} else {
				$ip_address_registered_country_names = '';
			}

			if (isset($response['ip_address']['city']['geoname_id'])) {
				$ip_address_city_geoname_id = $response['ip_address']['city']['geoname_id'];
			} else {
				$ip_address_city_geoname_id = '';
			}

			if (isset($response['ip_address']['city']['name'])) {
				$ip_address_city_name = $response['ip_address']['city']['name'];
			} else {
				$ip_address_city_name = '';
			}

			if (isset($response['ip_address']['city']['confidence'])) {
				$ip_address_city_confidence = $response['ip_address']['city']['confidence'];
			} else {
				$ip_address_city_confidence = '';
			}

			if (isset($response['ip_address']['city']['names'])) {
				$ip_address_city_names = $response['ip_address']['city']['names'];
			} else {
				$ip_address_city_names = '';
			}

			if (isset($response['ip_address']['continent']['geoname_id'])) {
				$ip_address_continent_geoname_id = $response['ip_address']['continent']['geoname_id'];
			} else {
				$ip_address_continent_geoname_id = '';
			}

			if (isset($response['ip_address']['continent']['name'])) {
				$ip_address_continent_name = str_replace("'", "\'", $response['ip_address']['continent']['name']);
			} else {
				$ip_address_continent_name = '';
			}

			if (isset($response['ip_address']['continent']['code'])) {
				$ip_address_continent_code = $response['ip_address']['continent']['code'];
			} else {
				$ip_address_continent_code = '';
			}

			if (isset($response['ip_address']['continent']['names'])) {
				$ip_address_continent_names = str_replace("'", "\'", $response['ip_address']['continent']['names']);
			} else {
				$ip_address_continent_names = '';
			}

			if (isset($response['ip_address']['traits']['user_type'])) {
				$ip_address_traits_user_type = $response['ip_address']['traits']['user_type'];
			} else {
				$ip_address_traits_user_type = '';
			}

			if (isset($response['ip_address']['traits']['organization'])) {
				$ip_address_traits_organization = $response['ip_address']['traits']['organization'];
			} else {
				$ip_address_traits_organization = '';
			}

			if (isset($response['ip_address']['traits']['autonomous_system_number'])) {
				$ip_address_traits_autonomous_system_number = $response['ip_address']['traits']['autonomous_system_number'];
			} else {
				$ip_address_traits_autonomous_system_number = '';
			}

			if (isset($response['ip_address']['traits']['domain'])) {
				$ip_address_traits_domain = $response['ip_address']['traits']['domain'];
			} else {
				$ip_address_traits_domain = '';
			}

			if (isset($response['ip_address']['traits']['is_legitimate_proxy']) && $response['ip_address']['traits']['is_legitimate_proxy'] == true) {
				$ip_address_traits_is_legitimate_proxy = 1;
			} else {
				$ip_address_traits_is_legitimate_proxy = 0;
			}

			if (isset($response['ip_address']['traits']['is_anonymous_proxy']) && $response['ip_address']['traits']['is_anonymous_proxy'] == true) {
				$ip_address_traits_is_anonymous_proxy = 1;
			} else {
				$ip_address_traits_is_anonymous_proxy = 0;
			}

			if (isset($response['ip_address']['traits']['isp'])) {
				$ip_address_traits_isp = $response['ip_address']['traits']['isp'];
			} else {
				$ip_address_traits_isp = '';
			}

			if (isset($response['ip_address']['traits']['autonomous_system_organization'])) {
				$ip_address_traits_autonomous_system_organization = $response['ip_address']['traits']['autonomous_system_organization'];
			} else {
				$ip_address_traits_autonomous_system_organization = '';
			}

			if (isset($response['ip_address']['traits']['ip_address'])) {
				$ip_address_traits_ip_address = $response['ip_address']['traits']['ip_address'];
			} else {
				$ip_address_traits_ip_address = '';
			}

			if (isset($response['ip_address']['traits']['is_satellite_provider']) && $response['ip_address']['traits']['is_satellite_provider'] == true) {
				$ip_address_traits_is_satellite_provider = 1;
			} else {
				$ip_address_traits_is_satellite_provider = 0;
			}

			if (isset($response['ip_address']['country']['geoname_id'])) {
				$ip_address_country_geoname_id = $response['ip_address']['country']['geoname_id'];
			} else {
				$ip_address_country_geoname_id = '';
			}

			if (isset($response['ip_address']['country']['name'])) {
				$ip_address_country_name = str_replace("'", "\'", $response['ip_address']['country']['name']);
			} else {
				$ip_address_country_name = '';
			}

			if (isset($response['ip_address']['country']['confidence'])) {
				$ip_address_country_confidence = $response['ip_address']['country']['confidence'];
			} else {
				$ip_address_country_confidence = '';
			}

			if (isset($response['ip_address']['country']['is_high_risk']) && $response['ip_address']['country']['is_high_risk'] == true) {
				$ip_address_country_is_high_risk = 1;
			} else {
				$ip_address_country_is_high_risk = 0;
			}

			if (isset($response['ip_address']['country']['names'])) {
				$ip_address_country_names = str_replace("'", "\'", $response['ip_address']['country']['names']);
			} else {
				$ip_address_country_names = '';
			}

			if (isset($response['ip_address']['country']['iso_code'])) {
				$ip_address_country_iso_code = $response['ip_address']['country']['iso_code'];
			} else {
				$ip_address_country_iso_code = '';
			}

			if (isset($response['ip_address']['risk'])) {
				$ip_address_risk = $response['ip_address']['risk'];
			} else {
				$ip_address_risk = '';
			}

			if (isset($response['ip_address']['subdivisions']['geoname_id'])) {
				$ip_address_subdivisions_geoname_id = $response['ip_address']['subdivisions']['geoname_id'];
			} else {
				$ip_address_subdivisions_geoname_id = '';
			}

			if (isset($response['ip_address']['subdivisions']['name'])) {
				$ip_address_subdivisions_name = str_replace("'", "\'", $response['ip_address']['subdivisions']['name']);
			} else {
				$ip_address_subdivisions_name = '';
			}

			if (isset($response['ip_address']['subdivisions']['iso_code'])) {
				$ip_address_subdivisions_iso_code = $response['ip_address']['subdivisions']['iso_code'];
			} else {
				$ip_address_subdivisions_iso_code = '';
			}

			if (isset($response['ip_address']['subdivisions']['confidence'])) {
				$ip_address_subdivisions_confidence = $response['ip_address']['subdivisions']['confidence'];
			} else {
				$ip_address_subdivisions_confidence = '';
			}

			if (isset($response['ip_address']['subdivisions']['names'])) {
				$ip_address_subdivisions_names = str_replace("'", "\'", $response['ip_address']['subdivisions']['names']);
			} else {
				$ip_address_subdivisions_names = '';
			}

			if (isset($response['ip_address']['location']['longitude'])) {
				$ip_address_location_longitude = $response['ip_address']['location']['longitude'];
			} else {
				$ip_address_location_longitude = '';
			}

			if (isset($response['ip_address']['location']['latitude'])) {
				$ip_address_location_latitude = $response['ip_address']['location']['latitude'];
			} else {
				$ip_address_location_latitude = '';
			}

			if (isset($response['ip_address']['location']['accuracy_radius'])) {
				$ip_address_location_accuracy_radius = $response['ip_address']['location']['accuracy_radius'];
			} else {
				$ip_address_location_accuracy_radius = '';
			}

			if (isset($response['ip_address']['location']['time_zone'])) {
				$ip_address_location_time_zone = $response['ip_address']['location']['time_zone'];
			} else {
				$ip_address_location_time_zone = '';
			}

			if (isset($response['ip_address']['location']['local_time'])) {
				$ip_address_location_local_time = $response['ip_address']['location']['local_time'];
			} else {
				$ip_address_location_local_time = '';
			}

			$query = ("INSERT INTO `" . DB_PREFIX . "alfaprotection`(`order_id`, `error`, `id`, `funds_remaining`, `queries_remaining`, `risk_score`, `ip_risk`, `status`, `status_messages`, `billing_is_in_ip_country`, `billing_longitude`, `billing_is_postal_in_city`, `billing_latitude`, `billing_distance_to_ip_location`, `shop_longitude`, `shop_is_high_risk`, `shop_distance_to_billing_address`, `shop_is_postal_in_city`, `shop_latitude`, `shop_is_in_ip_country`, `shop_distance_to_ip_location`, `user_is_high_risk`, `user_actis_freeion`, `card_is_issued_in_billing_address_country`, `card_country`, `card_issuer_matches_provided_phone_number`, `card_issuer_matches_provided_name`, `card_issuer_name`, `card_issuer_phone_number`, `card_is_prepaid`, `customer_id`, `ip_address_location_latitude`, `ip_address_location_longitude`, `ip_address_location_accuracy_radius`, `ip_address_location_time_zone`, `ip_address_location_local_time`, `ip_address_traits_is_legitimate_proxy`, `ip_address_traits_is_satellite_provider`, `ip_address_traits_ip_address`, `ip_address_traits_isp`, `ip_address_traits_is_anonymous_proxy`, `ip_address_traits_organization`, `ip_address_traits_autonomous_system_organization`, `ip_address_traits_user_type`, `ip_address_traits_autonomous_system_number`, `ip_address_traits_domain`, `ip_address_country_geoname_id`, `ip_address_country_name`, `ip_address_country_confidence`, `ip_address_country_is_high_risk`, `ip_address_country_names`, `ip_address_country_iso_code`, `ip_address_risk`, `ip_address_subdivisions_geoname_id`, `ip_address_subdivisions_name`, `ip_address_subdivisions_iso_code`, `ip_address_subdivisions_confidence`, `ip_address_subdivisions_names`, `ip_address_registered_country_is_high_risk`, `ip_address_registered_country_geoname_id`, `ip_address_registered_country_name`, `ip_address_registered_country_iso_code`, `ip_address_registered_country_names`, `ip_address_city_geoname_id`, `ip_address_city_name`, `ip_address_city_confidence`, `ip_address_city_names`, `ip_address_continent_geoname_id`, `ip_address_continent_name`, `ip_address_continent_confidence`, `ip_address_continent_names`) VALUES ('".$order_id."', '".$error."', '".$id."', '".$funds_remaining."', '".$queries_remaining."', '".$risk_score."', '".$ip_risk."', '".$status."', '".$status_messages."', '".$billing_is_in_ip_country."', '".$billing_longitude."', '".$billing_is_postal_in_city."', '".$billing_latitude."', '".$billing_distance_to_ip_location."', '".$shop_longitude."', '".$shop_is_high_risk."', '".$shop_distance_to_billing_address."', '".$shop_is_postal_in_city."', '".$shop_latitude."', '".$shop_is_in_ip_country."', '".$shop_distance_to_ip_location."', '".$user_is_high_risk."', '".$user_actis_freeion."', '".$card_is_issued_in_billing_address_country."', '".$card_country."', '".$card_issuer_matches_provided_phone_number."', '".$card_issuer_matches_provided_name."', '".$card_issuer_name."', '".$card_issuer_phone_number."', '".$card_is_prepaid."', '".$customer_id."', '".$ip_address_location_latitude."', '".$ip_address_location_longitude."', '".$ip_address_location_accuracy_radius."', '".$ip_address_location_time_zone."', '".$ip_address_location_local_time."', '".$ip_address_traits_is_legitimate_proxy."', '".$ip_address_traits_is_satellite_provider."', '".$ip_address_traits_ip_address."', '".$ip_address_traits_isp."', '".$ip_address_traits_is_anonymous_proxy."', '".$ip_address_traits_organization."', '".$ip_address_traits_autonomous_system_organization."', '".$ip_address_traits_user_type."', '".$ip_address_traits_autonomous_system_number."', '".$ip_address_traits_domain."', '".$ip_address_country_geoname_id."', '".$ip_address_country_name."', '".$ip_address_country_confidence."', '".$ip_address_country_is_high_risk."', '".$ip_address_country_names."', '".$ip_address_country_iso_code."', '".$ip_address_risk."', '".$ip_address_subdivisions_geoname_id."', '".$ip_address_subdivisions_name."', '".$ip_address_subdivisions_iso_code."', '".$ip_address_subdivisions_confidence."', '".$ip_address_subdivisions_names."', '".$ip_address_registered_country_is_high_risk."', '".$ip_address_registered_country_geoname_id."', '".$ip_address_registered_country_name."', '".$ip_address_registered_country_iso_code."', '".$ip_address_registered_country_names."', '".$ip_address_city_geoname_id."', '".$ip_address_city_name."', '".$ip_address_city_confidence."', '".$ip_address_city_names."', '".$ip_address_continent_geoname_id."', '".$ip_address_continent_name."', '".$ip_address_continent_confidence."', '".$ip_address_continent_names."')");

			$fp = fopen("test.php", "a"); // Открываем файл в режиме записи
			ftruncate($fp, 0);
			$test = fwrite($fp, $error); // Запись в файл
			fclose($fp); //Закрытие файла

			$this->db->query($query);

			if ($status == 'decline') {
				$querye = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE name = 'Decline' AND language_id = '" . (int)$this->config->get('config_language_id') . "'");
				$ress = $querye->row;
				return $ress['order_status_id'];
			}

			if ($status == 'approved') {
				$querye = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE name = 'Approved' AND language_id = '" . (int)$this->config->get('config_language_id') . "'");
				$ress = $querye->row;
				return $ress['order_status_id'];
			}

			if ($status == 'manual_check') {
				$querye = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE name = 'Manual check' AND language_id = '" . (int)$this->config->get('config_language_id') . "'");
				$ress = $querye->row;
				return $ress['order_status_id'];
			}
			

		}
		if ($error == 'true') {

			$error_message = $data_response['message'];
			$query = ("INSERT INTO `" . DB_PREFIX . "alfaprotection`(`order_id`, `error`, `error_message`,) VALUES ('".$order_id."', '".$error."', '".$error_message."')");

			$fp = fopen("test.php", "a"); // Открываем файл в режиме записи
			ftruncate($fp, 0);
			$test = fwrite($fp, $error); // Запись в файл
			fclose($fp); //Закрытие файла
			$this->db->query($query);
		}
	}
}