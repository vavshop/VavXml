<?php
// Heading
$_['heading_title']                           = 'Alfa Protection Anti-Fraud';

// Entry
$_['entry_key']                               = 'Alfa Protection License Key';
$_['entry_google']                            = 'AGoogle Map API Key';
$_['entry_score']                             = 'Risk Score';
$_['entry_risk_score_max']                    = 'Limit manual check';
$_['entry_risk_score_min']                    = 'Limit approved';
$_['entry_order_status']                      = 'Order Status';
$_['entry_status']                            = 'Status';

$_['help_key']               = 'A license key can be obtained from AlfaProtection.com
   This module will not work without a license key';
$_['help_risk_score_min']               = 'All orders that will receive Risk Score less than the specified number will be approved. All that more will receive a Manual Check. Or another value that you will choose.';
$_['help_risk_score_max']               = 'Averything that is more than the specified value will be automatically Declined';
$_['help_google']               = 'This key is needed to display the Google Map in the details of the order';



$_['help_error']                              = 'Returns an error string with a warning message or a reason why the request failed.';

// Error
$_['error_permission']                        = 'Warning: You do not have permission to modify Alfa Protection anti-fraud!';

// Text
$_['text_fraud']                              = 'Anti-Fraud';
$_['text_success']                            = 'Success: You have modified Alfa Protection anti-fraud!';
$_['text_edit']                               = 'Edit Alfa Protection Anti-Fraud';
$_['text_signup']                             = 'Alfa Protection is a fraud detection service. If you don\'t have a license key you can <a href="http://www.alfaprotection.com/" target="_blank"><u>sign up here</u></a>.';
$_['text_order_id']                                   = 'License Key Required!';
$_['text_funds_remaining']                            = '';
$_['text_queries_remaining']                          = '';
$_['text_risk_score']                                 = 'Risk score';
$_['text_ip_risk']                                    = 'Ip risk';
$_['text_status']                                     = 'Status';
$_['text_status_messages']                            = 'Status messages';
$_['text_billing_is_in_ip_country']                   = 'Is in ip country';
$_['text_billing_longitude']                          = 'Longitude';
$_['text_billing_is_postal_in_city']                  = 'Is postal in city';
$_['text_billing_latitude']                           = 'Latitude';
$_['text_billing_distance_to_ip_location']            = 'Distance to ip location';
$_['text_shop_longitude']                             = 'Longitude';
$_['text_shop_is_high_risk']                          = 'Is high risk';
$_['text_shop_distance_to_billing_address']           = 'Distance to billing address';
$_['text_shop_is_postal_in_city']                     = 'Is postal in city';
$_['text_shop_latitude']                              = 'Latitude';
$_['text_shop_is_in_ip_country']                      = 'Is in ip country';
$_['text_shop_distance_to_ip_location']               = 'Distance to ip location';
$_['text_user_is_high_risk']                          = 'Is high risk';
$_['text_user_actis_freeion']                         = 'License Key Required!';
$_['text_card_is_issued_in_billing_address_country']  = 'Is issued in billing address country';
$_['text_card_country']                               = 'Country';
$_['text_card_issuer_matches_provided_phone_number']  = 'Matches provided phone number';
$_['text_card_issuer_matches_provided_name']          = 'Matches provided name';
$_['text_card_issuer_name']                           = 'Name';
$_['text_card_issuer_phone_number']                   = 'Matches provided phone number';
$_['text_card_is_prepaid']                            = 'Is prepaid';
$_['text_customer_id']                                = '';
$_['text_ip_address_location_latitude']               = 'Latitude';
$_['text_ip_address_location_longitude']              = 'Longitude';
$_['text_ip_address_location_accuracy_radius']        = 'Accuracy radius';
$_['text_ip_address_location_time_zone']              = 'Time zone';
$_['text_ip_address_location_local_time']             = 'Local time';
$_['text_ip_address_traits_is_legitimate_proxy']      = 'Is legitimate proxy';
$_['text_ip_address_traits_is_satellite_provider']    = 'Is satellite provider';
$_['text_ip_address_traits_ip_address']               = 'Ip address';
$_['text_ip_address_traits_isp']                      = 'Isp';
$_['text_ip_address_traits_is_anonymous_proxy']       = 'Is anonymous proxy';
$_['text_ip_address_traits_organization']             = 'Organization';
$_['text_ip_address_traits_autonomous_system_organization']    = 'Autonomous system organization';
$_['text_ip_address_traits_user_type']                = 'Connection type';
$_['text_ip_address_traits_autonomous_system_number'] = 'Autonomous system number';
$_['text_ip_address_traits_domain']                   = 'Domain';
$_['text_ip_address_country_geoname_id']              = 'Geoname id';
$_['text_ip_address_country_name']                    = 'Name';
$_['text_ip_address_country_confidence']              = 'Code';
$_['text_ip_address_country_is_high_risk']            = 'Is high risk';
$_['text_ip_address_country_names']                   = 'Names';
$_['text_ip_address_country_iso_code']          			= 'Iso code';
$_['text_ip_address_risk']                            = 'Ip risk';
$_['text_ip_address_subdivisions_geoname_id']         = 'Geoname id';
$_['text_ip_address_subdivisions_name']               = 'Name';
$_['text_ip_address_subdivisions_iso_code']           = 'Iso code';
$_['text_ip_address_subdivisions_confidence']         = 'Confidence';
$_['text_ip_address_subdivisions_names']              = 'Names';
$_['text_ip_address_registered_country_is_high_risk'] = 'Is high risk';
$_['text_ip_address_registered_country_geoname_id']   = 'Geoname id';
$_['text_ip_address_registered_country_name']         = 'Name';
$_['text_ip_address_registered_country_iso_code']     = 'Iso code';
$_['text_ip_address_registered_country_names']        = 'Names';
$_['text_ip_address_city_geoname_id']                 = 'Geoname id';
$_['text_ip_address_city_name']                       = 'Name';
$_['text_ip_address_city_confidence']                 = 'Confidence';
$_['text_ip_address_city_names']                      = 'Names';
$_['text_ip_address_continent_geoname_id']            = 'Geoname id';
$_['text_ip_address_continent_name']                  = 'Name';
$_['text_ip_address_continent_confidence']            = 'Code';
$_['text_ip_address_continent_names']                 = 'Names';
$_['text_status_messages']                            = 'Text status messages';


