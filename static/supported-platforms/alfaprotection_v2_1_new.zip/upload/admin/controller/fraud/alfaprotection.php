<?php
class ControllerFraudAlfaProtection extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('fraud/alfaprotection');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('alfaprotection', $this->request->post);
			$set_risck_score = array(
				'secret' => $this->request->post['alfaprotection_key'],
				'code_name' => 'risk_score',
				'min_val' => $this->request->post['alfaprotection_risk_score_min'],
				'max_val' => $this->request->post['alfaprotection_risk_score_max'],
				);

			$curl = curl_init();

			curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8'));
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($curl, CURLOPT_URL, 'https://alfaprotection.com/protect/api/set/rules/');
			curl_setopt($curl, CURLOPT_POST, 1);
			curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($set_risck_score));
			$res = curl_exec($curl);
			curl_close($curl);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/fraud', 'token=' . $this->session->data['token'], 'SSL'));
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_signup'] = $this->language->get('text_signup');

		$data['entry_key'] = $this->language->get('entry_key');
		$data['entry_score'] = $this->language->get('entry_score');
		$data['entry_risk_score_min'] = $this->language->get('entry_risk_score_min');
		$data['entry_risk_score_max'] = $this->language->get('entry_risk_score_max');
		$data['entry_order_status'] = $this->language->get('entry_order_status');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_google'] = $this->language->get('entry_google');

		$data['help_score'] = $this->language->get('help_score');
		$data['help_order_status'] = $this->language->get('help_order_status');

		$data['help_key'] = $this->language->get('help_key');
		$data['help_risk_score_min'] = $this->language->get('help_risk_score_min');
		$data['help_risk_score_max'] = $this->language->get('help_risk_score_max');
		$data['help_google'] = $this->language->get('help_google');


		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		$data['tab_general'] = $this->language->get('tab_general');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['key'])) {
			$data['error_key'] = $this->error['key'];
		} else {
			$data['error_key'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('extension/fraud', 'token=' . $this->session->data['token'] . '&type=fraud', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('fraud/alfaprotection', 'token=' . $this->session->data['token'], true)
		);

		$data['action'] = $this->url->link('fraud/alfaprotection', 'token=' . $this->session->data['token'], true);

		$data['cancel'] = $this->url->link('extension/fraud', 'token=' . $this->session->data['token'] . '&type=fraud', true);


		if ($this->config->get('alfaprotection_key')) {
			$get_risck_score = array('secret' => $this->config->get('alfaprotection_key'), 'code_name' => 'risk_score');
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8'));
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_URL, 'https://alfaprotection.com/protect/api/get/rules/');
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($get_risck_score));
			$result = curl_exec($ch);
			curl_close($ch);
		} else {
			$result = '';
		}

		if (isset($this->request->post['alfaprotection_key'])) {
			$data['alfaprotection_key'] = $this->request->post['alfaprotection_key'];
		} else {
			$data['alfaprotection_key'] = $this->config->get('alfaprotection_key');
		}

		if (isset($this->request->post['alfaprotection_google'])) {
			$data['alfaprotection_google'] = $this->request->post['alfaprotection_google'];
		} else {
			$data['alfaprotection_google'] = $this->config->get('alfaprotection_google');
		}

		if(!empty($result)) {
			$score = json_decode($result, true);
		} else {
			$score = '';
		}

		if (!empty($score['min_val'])) {
			$data['alfaprotection_risk_score_min'] = $score['min_val'];
		} else	if (isset($this->request->post['alfaprotection_risk_score_min'])) {
			$data['alfaprotection_risk_score_min'] = $this->request->post['alfaprotection_risk_score_min'];
		} else {
			$data['alfaprotection_risk_score_min'] = $this->config->get('alfaprotection_risk_score_min');
		}

		if (!empty($score['max_val'])) {
			$data['alfaprotection_risk_score_max'] = $score['max_val'];
		} else	if (isset($this->request->post['alfaprotection_risk_score_max'])) {
			$data['alfaprotection_risk_score_max'] = $this->request->post['alfaprotection_score'];
		} else {
			$data['alfaprotection_risk_score_max'] = $this->config->get('alfaprotection_risk_score_max');
		}

		// if (isset($this->request->post['alfaprotection_order_status_id'])) {
		// 	$data['alfaprotection_order_status_id'] = $this->request->post['alfaprotection_order_status_id'];
		// } else {
		// 	$data['alfaprotection_order_status_id'] = $this->config->get('alfaprotection_order_status_id');
		// }

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		if (isset($this->request->post['alfaprotection_status'])) {
			$data['alfaprotection_status'] = $this->request->post['alfaprotection_status'];
		} else {
			$data['alfaprotection_status'] = $this->config->get('alfaprotection_status');
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('fraud/alfaprotection.tpl', $data));
	}

	public function install() {
		$this->load->model('fraud/alfaprotection');

		$this->model_fraud_alfaprotection->install();
	}

	public function uninstall() {
		$this->load->model('fraud/alfaprotection');

		$this->model_fraud_alfaprotection->uninstall();
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'fraud/alfaprotection')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['alfaprotection_key']) {
			$this->error['key'] = $this->language->get('error_key');
		}

		return !$this->error;
	}

	public function order() {
		$this->load->language('fraud/alfaprotection');

		$this->load->model('fraud/alfaprotection');

		if (isset($this->request->get['order_id'])) {
			$order_id = $this->request->get['order_id'];
		} else {
			$order_id = 0;
		}

		$fraud_info = $this->model_fraud_alfaprotection->getOrder($order_id);

		if ($fraud_info) {

			$data['text_order_id'] = $this->language->get('text_order_id');
			$data['text_funds_remaining'] = $this->language->get('text_funds_remaining');
			$data['text_queries_remaining'] = $this->language->get('text_queries_remaining');
			$data['text_risk_score'] = $this->language->get('text_risk_score');
			$data['text_ip_risk'] = $this->language->get('text_ip_risk');
			$data['text_status'] = $this->language->get('text_status');
			$data['status_messages'] = $this->language->get('status_messages');
			$data['text_billing_is_in_ip_country'] = $this->language->get('text_billing_is_in_ip_country');
			$data['text_billing_longitude'] = $this->language->get('text_billing_longitude');
			$data['text_billing_is_postal_in_city'] = $this->language->get('text_billing_is_postal_in_city');
			$data['text_billing_latitude'] = $this->language->get('text_billing_latitude');
			$data['text_billing_distance_to_ip_location'] = $this->language->get('text_billing_distance_to_ip_location');
			$data['text_shop_longitude'] = $this->language->get('text_shop_longitude');
			$data['text_shop_is_high_risk'] = $this->language->get('text_shop_is_high_risk');
			$data['text_shop_distance_to_billing_address'] = $this->language->get('text_shop_distance_to_billing_address');
			$data['text_shop_is_postal_in_city'] = $this->language->get('text_shop_is_postal_in_city');
			$data['text_shop_latitude'] = $this->language->get('text_shop_latitude');
			$data['text_shop_is_in_ip_country'] = $this->language->get('text_shop_is_in_ip_country');
			$data['text_shop_distance_to_ip_location'] = $this->language->get('text_shop_distance_to_ip_location');
			$data['text_user_is_high_risk'] = $this->language->get('text_user_is_high_risk');
			$data['text_user_actis_freeion'] = $this->language->get('text_user_actis_freeion');
			$data['text_card_is_issued_in_billing_address_country'] = $this->language->get('text_card_is_issued_in_billing_address_country');
			$data['text_card_country'] = $this->language->get('text_card_country');
			$data['text_card_issuer_matches_provided_phone_number'] = $this->language->get('text_card_issuer_matches_provided_phone_number');
			$data['text_card_issuer_matches_provided_name'] = $this->language->get('text_card_issuer_matches_provided_name');
			$data['text_card_issuer_name'] = $this->language->get('text_card_issuer_name');
			$data['text_card_issuer_phone_number'] = $this->language->get('text_card_issuer_phone_number');
			$data['text_card_is_prepaid'] = $this->language->get('text_card_is_prepaid');
			$data['text_customer_id'] = $this->language->get('text_customer_id');
			$data['text_ip_address_location_latitude'] = $this->language->get('text_ip_address_location_latitude');
			$data['text_ip_address_location_longitude'] = $this->language->get('text_ip_address_location_longitude');
			$data['text_ip_address_location_accuracy_radius'] = $this->language->get('text_ip_address_location_accuracy_radius');
			$data['text_ip_address_location_time_zone'] = $this->language->get('text_ip_address_location_time_zone');
			$data['text_ip_address_location_local_time'] = $this->language->get('text_ip_address_location_local_time');
			$data['text_ip_address_traits_is_legitimate_proxy'] = $this->language->get('text_ip_address_traits_is_legitimate_proxy');
			$data['text_ip_address_traits_is_satellite_provider'] = $this->language->get('text_ip_address_traits_is_satellite_provider');
			$data['text_ip_address_traits_ip_address'] = $this->language->get('text_ip_address_traits_ip_address');
			$data['text_ip_address_traits_isp'] = $this->language->get('text_ip_address_traits_isp');
			$data['text_ip_address_traits_is_anonymous_proxy'] = $this->language->get('text_ip_address_traits_is_anonymous_proxy');
			$data['text_ip_address_traits_organization'] = $this->language->get('text_ip_address_traits_organization');
			$data['text_ip_address_traits_autonomous_system_organization'] = $this->language->get('text_ip_address_traits_autonomous_system_organization');
			$data['text_ip_address_traits_user_type'] = $this->language->get('text_ip_address_traits_user_type');
			$data['text_ip_address_traits_autonomous_system_number'] = $this->language->get('text_ip_address_traits_autonomous_system_number');
			$data['text_ip_address_traits_domain'] = $this->language->get('text_ip_address_traits_domain');
			$data['text_ip_address_country_geoname_id'] = $this->language->get('text_ip_address_country_geoname_id');
			$data['text_ip_address_country_name'] = $this->language->get('text_ip_address_country_name');
			$data['text_ip_address_country_confidence'] = $this->language->get('text_ip_address_country_confidence');
			$data['text_ip_address_country_is_high_risk'] = $this->language->get('text_ip_address_country_is_high_risk');
			$data['text_ip_address_country_names'] = $this->language->get('text_ip_address_country_names');
			$data['text_ip_address_country_iso_code'] = $this->language->get('text_ip_address_country_iso_code');
			$data['text_ip_address_risk'] = $this->language->get('text_ip_address_risk');
			$data['text_ip_address_subdivisions_geoname_id'] = $this->language->get('text_ip_address_subdivisions_geoname_id');
			$data['text_ip_address_subdivisions_name'] = $this->language->get('text_ip_address_subdivisions_name');
			$data['text_ip_address_subdivisions_iso_code'] = $this->language->get('text_ip_address_subdivisions_iso_code');
			$data['text_ip_address_subdivisions_confidence'] = $this->language->get('text_ip_address_subdivisions_confidence');
			$data['text_ip_address_subdivisions_names'] = $this->language->get('text_ip_address_subdivisions_names');
			$data['text_ip_address_registered_country_is_high_risk'] = $this->language->get('text_ip_address_registered_country_is_high_risk');
			$data['text_ip_address_registered_country_geoname_id'] = $this->language->get('text_ip_address_registered_country_geoname_id');
			$data['text_ip_address_registered_country_name'] = $this->language->get('text_ip_address_registered_country_name');
			$data['text_ip_address_registered_country_iso_code'] = $this->language->get('text_ip_address_registered_country_iso_code');
			$data['text_ip_address_registered_country_names'] = $this->language->get('text_ip_address_registered_country_names');
			$data['text_ip_address_city_geoname_id'] = $this->language->get('text_ip_address_city_geoname_id');
			$data['text_ip_address_city_name'] = $this->language->get('text_ip_address_city_name');
			$data['text_ip_address_city_confidence'] = $this->language->get('text_ip_address_city_confidence');
			$data['text_ip_address_city_names'] = $this->language->get('text_ip_address_city_names');
			$data['text_ip_address_continent_geoname_id'] = $this->language->get('text_ip_address_continent_geoname_id');
			$data['text_ip_address_continent_name'] = $this->language->get('text_ip_address_continent_name');
			$data['text_ip_address_continent_confidence'] = $this->language->get('text_ip_address_continent_confidence');
			$data['text_ip_address_continent_names'] = $this->language->get('text_ip_address_continent_names');
			$data['text_status_messages'] = $this->language->get('text_status_messages');


			if ($fraud_info['order_id']) {
				$data['order_id'] = $fraud_info['order_id'];
			} else {
				$data['order_id'] = 'N/A';
			}

			if ($fraud_info['id']) {
				$data['id'] = $fraud_info['id'];
			} else {
				$data['id'] = 'N/A';
			}

			if ($fraud_info['funds_remaining']) {
				$data['funds_remaining'] = $fraud_info['funds_remaining'];
			} else {
				$data['funds_remaining'] = 'N/A';
			}

			if ($fraud_info['status']) {
				$data['status'] = $fraud_info['status'];
			} else {
				$data['status'] = 'N/A';
			}



			if ($fraud_info['status_messages']) {
				$status_messages = json_decode($fraud_info['status_messages'], true);
				$data['status_messages'] = $status_messages;
			} else {
				$data['status_messages'] = '';
			}

			$querye = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE name = 'Approved' AND language_id = '" . (int)$this->config->get('config_language_id') . "'");
				$ress = $querye->row;
				$data['status_id'] = $ress['order_status_id'];

			if ($fraud_info['queries_remaining']) {
				$data['queries_remaining'] = $fraud_info['queries_remaining'];
			} else {
				$data['queries_remaining'] = 'N/A';
			}

			if ($fraud_info['risk_score']) {
				$data['risk_score'] = $fraud_info['risk_score'];
			} else {
				$data['risk_score'] = 'N/A';
			}

			if ($fraud_info['ip_risk']) {
				$data['ip_risk'] = $fraud_info['ip_risk'];
			} else {
				$data['ip_risk'] = 'N/A';
			}

			if ($fraud_info['status']) {
				$data['status'] = $fraud_info['status'];
			} else {
				$data['status'] = 'N/A';
			}

			if ($fraud_info['billing_is_in_ip_country'] == 1) {
				$data['billing_is_in_ip_country'] = 'true';
			} else {
				$data['billing_is_in_ip_country'] = 'false';
			}

			if ($fraud_info['billing_longitude']) {
				$data['billing_longitude'] = $fraud_info['billing_longitude'];
			} else {
				$data['billing_longitude'] = 'N/A';
			}

			if ($fraud_info['billing_is_postal_in_city'] == 1) {
				$data['billing_is_postal_in_city'] = 'true';
			} else {
				$data['billing_is_postal_in_city'] = 'false';
			}

			if ($fraud_info['billing_latitude']) {
				$data['billing_latitude'] = $fraud_info['billing_latitude'];
			} else {
				$data['billing_latitude'] = 'N/A';
			}

			if ($fraud_info['billing_distance_to_ip_location']) {
				$data['billing_distance_to_ip_location'] = $fraud_info['billing_distance_to_ip_location'];
			} else {
				$data['billing_distance_to_ip_location'] = 'N/A';
			}

			if ($fraud_info['shop_longitude']) {
				$data['shop_longitude'] = $fraud_info['shop_longitude'];
			} else {
				$data['shop_longitude'] = 'N/A';
			}

			if ($fraud_info['shop_is_high_risk'] == 1) {
				$data['shop_is_high_risk'] = 'true';
			} else {
				$data['shop_is_high_risk'] = 'false';
			}

			if ($fraud_info['shop_distance_to_billing_address']) {
				$data['shop_distance_to_billing_address'] = $fraud_info['shop_distance_to_billing_address'];
			} else {
				$data['shop_distance_to_billing_address'] = 'N/A';
			}

			if ($fraud_info['shop_is_postal_in_city'] == 1) {
				$data['shop_is_postal_in_city'] = 'true';
			} else {
				$data['shop_is_postal_in_city'] = 'false';
			}

			if ($fraud_info['shop_latitude']) {
				$data['shop_latitude'] = $fraud_info['shop_latitude'];
			} else {
				$data['shop_latitude'] = 'N/A';
			}

			if ($fraud_info['shop_is_in_ip_country'] == 1) {
				$data['shop_is_in_ip_country'] = 'true';
			} else {
				$data['shop_is_in_ip_country'] = 'false';
			}

			if ($fraud_info['shop_distance_to_ip_location']) {
				$data['shop_distance_to_ip_location'] = $fraud_info['shop_distance_to_ip_location'];
			} else {
				$data['shop_distance_to_ip_location'] = 'N/A';
			}

			if ($fraud_info['user_is_high_risk'] == 1) {
				$data['user_is_high_risk'] = 'true';
			} else {
				$data['user_is_high_risk'] = 'false';
			}

			if ($fraud_info['user_actis_freeion']) {
				$data['user_actis_freeion'] = $fraud_info['user_actis_freeion'];
			} else {
				$data['user_actis_freeion'] = 'N/A';
			}

			if ($fraud_info['id']) {
				$data['id'] = $fraud_info['id'];
			} else {
				$data['id'] = 'N/A';
			}

			if ($fraud_info['card_is_issued_in_billing_address_country'] == 1) {
				$data['card_is_issued_in_billing_address_country'] = 'true';
			} else {
				$data['card_is_issued_in_billing_address_country'] = 'false';
			}

			if ($fraud_info['card_country']) {
				$data['card_country'] = $fraud_info['card_country'];
			} else {
				$data['card_country'] = 'N/A';
			}

			if ($fraud_info['card_issuer_matches_provided_phone_number']) {
				$data['card_issuer_matches_provided_phone_number'] = $fraud_info['card_issuer_matches_provided_phone_number'];
			} else {
				$data['card_issuer_matches_provided_phone_number'] = 'N/A';
			}

			if ($fraud_info['card_country']) {
				$data['card_country'] = $fraud_info['card_country'];
			} else {
				$data['card_country'] = 'N/A';
			}

			if ($fraud_info['card_issuer_matches_provided_phone_number']) {
				$data['card_issuer_matches_provided_phone_number'] = $fraud_info['card_issuer_matches_provided_phone_number'];
			} else {
				$data['card_issuer_matches_provided_phone_number'] = 'N/A';
			}

			if ($fraud_info['card_issuer_matches_provided_name']) {
				$data['card_issuer_matches_provided_name'] = $fraud_info['card_issuer_matches_provided_name'];
			} else {
				$data['card_issuer_matches_provided_name'] = 'N/A';
			}

			if ($fraud_info['card_issuer_name']) {
				$data['card_issuer_name'] = $fraud_info['card_issuer_name'];
			} else {
				$data['card_issuer_name'] = 'N/A';
			}

			if ($fraud_info['card_issuer_phone_number']) {
				$data['card_issuer_phone_number'] = $fraud_info['card_issuer_phone_number'];
			} else {
				$data['card_issuer_phone_number'] = 'N/A';
			}

			if ($fraud_info['card_is_prepaid'] == 1) {
				$data['card_is_prepaid'] = 'true';
			} else {
				$data['card_is_prepaid'] = 'false';
			}

			if ($fraud_info['customer_id']) {
				$data['customer_id'] = $fraud_info['customer_id'];
			} else {
				$data['customer_id'] = 'N/A';
			}

			if ($fraud_info['ip_address_location_latitude']) {
				$data['ip_address_location_latitude'] = $fraud_info['ip_address_location_latitude'];
			} else {
				$data['ip_address_location_latitude'] = 'N/A';
			}

			if ($fraud_info['ip_address_location_longitude']) {
				$data['ip_address_location_longitude'] = $fraud_info['ip_address_location_longitude'];
			} else {
				$data['ip_address_location_longitude'] = 'N/A';
			}

			if ($fraud_info['ip_address_location_accuracy_radius']) {
				$data['ip_address_location_accuracy_radius'] = $fraud_info['ip_address_location_accuracy_radius'];
			} else {
				$data['ip_address_location_accuracy_radius'] = 'N/A';
			}

			if ($fraud_info['ip_address_location_time_zone']) {
				$data['ip_address_location_time_zone'] = $fraud_info['ip_address_location_time_zone'];
			} else {
				$data['ip_address_location_time_zone'] = 'N/A';
			}

			if ($fraud_info['ip_address_location_local_time']) {
				$data['ip_address_location_local_time'] = $fraud_info['ip_address_location_local_time'];
			} else {
				$data['ip_address_location_local_time'] = 'N/A';
			}

			if ($fraud_info['ip_address_traits_is_legitimate_proxy'] == 1) {
				$data['ip_address_traits_is_legitimate_proxy'] = 'true';
			} else {
				$data['ip_address_traits_is_legitimate_proxy'] = 'false';
			}

			if ($fraud_info['ip_address_traits_is_satellite_provider'] == 1) {
				$data['ip_address_traits_is_satellite_provider'] = 'true';
			} else {
				$data['ip_address_traits_is_satellite_provider'] = 'false';
			}

			if ($fraud_info['ip_address_traits_ip_address']) {
				$data['ip_address_traits_ip_address'] = $fraud_info['ip_address_traits_ip_address'];
			} else {
				$data['ip_address_traits_ip_address'] = 'N/A';
			}

			if ($fraud_info['ip_address_traits_isp']) {
				$data['ip_address_traits_isp'] = $fraud_info['ip_address_traits_isp'];
			} else {
				$data['ip_address_traits_isp'] = 'N/A';
			}

			if ($fraud_info['ip_address_traits_is_anonymous_proxy'] == 1) {
				$data['ip_address_traits_is_anonymous_proxy'] = 'true';
			} else {
				$data['ip_address_traits_is_anonymous_proxy'] = 'false';
			}

			if ($fraud_info['ip_address_traits_organization']) {
				$data['ip_address_traits_organization'] = $fraud_info['ip_address_traits_organization'];
			} else {
				$data['ip_address_traits_organization'] = 'N/A';
			}

			if ($fraud_info['ip_address_traits_autonomous_system_organization']) {
				$data['ip_address_traits_autonomous_system_organization'] = $fraud_info['ip_address_traits_autonomous_system_organization'];
			} else {
				$data['ip_address_traits_autonomous_system_organization'] = 'N/A';
			}

			if ($fraud_info['ip_address_traits_user_type']) {
				$data['ip_address_traits_user_type'] = $fraud_info['ip_address_traits_user_type'];
			} else {
				$data['ip_address_traits_user_type'] = 'N/A';
			}

			if ($fraud_info['ip_address_traits_autonomous_system_number']) {
				$data['ip_address_traits_autonomous_system_number'] = $fraud_info['ip_address_traits_autonomous_system_number'];
			} else {
				$data['ip_address_traits_autonomous_system_number'] = 'N/A';
			}

			if ($fraud_info['ip_address_traits_domain']) {
				$data['ip_address_traits_domain'] = $fraud_info['ip_address_traits_domain'];
			} else {
				$data['ip_address_traits_domain'] = 'N/A';
			}

			if ($fraud_info['ip_address_country_geoname_id']) {
				$data['ip_address_country_geoname_id'] = $fraud_info['ip_address_country_geoname_id'];
			} else {
				$data['ip_address_country_geoname_id'] = 'N/A';
			}

			if ($fraud_info['ip_address_country_name']) {
				$data['ip_address_country_name'] = $fraud_info['ip_address_country_name'];
			} else {
				$data['ip_address_country_name'] = 'N/A';
			}

			if ($fraud_info['ip_address_country_confidence']) {
				$data['ip_address_country_confidence'] = $fraud_info['ip_address_country_confidence'];
			} else {
				$data['ip_address_country_confidence'] = 'N/A';
			}

			if ($fraud_info['ip_address_country_is_high_risk'] == 1) {
				$data['ip_address_country_is_high_risk'] = 'true';
			} else {
				$data['ip_address_country_is_high_risk'] = 'false';
			}

			if ($fraud_info['ip_address_country_names']) {
				$data['ip_address_country_names'] = $fraud_info['ip_address_country_names'];
			} else {
				$data['ip_address_country_names'] = 'N/A';
			}

			if ($fraud_info['ip_address_country_iso_code']) {
				$data['ip_address_country_iso_code'] = $fraud_info['ip_address_country_iso_code'];
			} else {
				$data['ip_address_country_iso_code'] = 'N/A';
			}

			if ($fraud_info['ip_address_risk']) {
				$data['ip_address_risk'] = $fraud_info['ip_address_risk'];
			} else {
				$data['ip_address_risk'] = 'N/A';
			}

			if ($fraud_info['ip_address_subdivisions_geoname_id']) {
				$data['ip_address_subdivisions_geoname_id'] = $fraud_info['ip_address_subdivisions_geoname_id'];
			} else {
				$data['ip_address_subdivisions_geoname_id'] = 'N/A';
			}

			if ($fraud_info['ip_address_subdivisions_name']) {
				$data['ip_address_subdivisions_name'] = $fraud_info['ip_address_subdivisions_name'];
			} else {
				$data['ip_address_subdivisions_name'] = 'N/A';
			}

			if ($fraud_info['ip_address_subdivisions_iso_code']) {
				$data['ip_address_subdivisions_iso_code'] = $fraud_info['ip_address_subdivisions_iso_code'];
			} else {
				$data['ip_address_subdivisions_iso_code'] = 'N/A';
			}

			if ($fraud_info['ip_address_subdivisions_confidence']) {
				$data['ip_address_subdivisions_confidence'] = $fraud_info['ip_address_subdivisions_confidence'];
			} else {
				$data['ip_address_subdivisions_confidence'] = 'N/A';
			}

			if ($fraud_info['ip_address_subdivisions_names']) {
				$data['ip_address_subdivisions_names'] = $fraud_info['ip_address_subdivisions_names'];
			} else {
				$data['ip_address_subdivisions_names'] = 'N/A';
			}

			if ($fraud_info['ip_address_registered_country_is_high_risk'] == 1) {
				$data['ip_address_registered_country_is_high_risk'] = 'true';
			} else {
				$data['ip_address_registered_country_is_high_risk'] = 'false';
			}

			if ($fraud_info['ip_address_registered_country_geoname_id']) {
				$data['ip_address_registered_country_geoname_id'] = $fraud_info['ip_address_registered_country_geoname_id'];
			} else {
				$data['ip_address_registered_country_geoname_id'] = 'N/A';
			}

			if ($fraud_info['ip_address_registered_country_name']) {
				$data['ip_address_registered_country_name'] = $fraud_info['ip_address_registered_country_name'];
			} else {
				$data['ip_address_registered_country_name'] = 'N/A';
			}

			if ($fraud_info['ip_address_registered_country_iso_code']) {
				$data['ip_address_registered_country_iso_code'] = $fraud_info['ip_address_registered_country_iso_code'];
			} else {
				$data['ip_address_registered_country_iso_code'] = 'N/A';
			}

			if ($fraud_info['ip_address_registered_country_names']) {
				$data['ip_address_registered_country_names'] = $fraud_info['ip_address_registered_country_names'];
			} else {
				$data['ip_address_registered_country_names'] = 'N/A';
			}

			if ($fraud_info['ip_address_city_geoname_id']) {
				$data['ip_address_city_geoname_id'] = $fraud_info['ip_address_city_geoname_id'];
			} else {
				$data['ip_address_city_geoname_id'] = 'N/A';
			}

			if ($fraud_info['ip_address_city_name']) {
				$data['ip_address_city_name'] = $fraud_info['ip_address_city_name'];
			} else {
				$data['ip_address_city_name'] = 'N/A';
			}

			if ($fraud_info['ip_address_city_confidence']) {
				$data['ip_address_city_confidence'] = $fraud_info['ip_address_city_confidence'];
			} else {
				$data['ip_address_city_confidence'] = 'N/A';
			}

			if ($fraud_info['ip_address_city_names']) {
				$data['ip_address_city_names'] = $fraud_info['ip_address_city_names'];
			} else {
				$data['ip_address_city_names'] = 'N/A';
			}

			if ($fraud_info['ip_address_continent_geoname_id']) {
				$data['ip_address_continent_geoname_id'] = $fraud_info['ip_address_continent_geoname_id'];
			} else {
				$data['ip_address_continent_geoname_id'] = 'N/A';
			}

			if ($fraud_info['ip_address_continent_name']) {
				$data['ip_address_continent_name'] = $fraud_info['ip_address_continent_name'];
			} else {
				$data['ip_address_continent_name'] = 'N/A';
			}

			if ($fraud_info['ip_address_continent_confidence']) {
				$data['ip_address_continent_confidence'] = $fraud_info['ip_address_continent_confidence'];
			} else {
				$data['ip_address_continent_confidence'] = 'N/A';
			}

			if ($fraud_info['ip_address_continent_names']) {
				$data['ip_address_continent_names'] = $fraud_info['ip_address_continent_names'];
			} else {
				$data['ip_address_continent_names'] = 'N/A';
			}

			if ($this->config->get('alfaprotection_google')) {
				$data['alfaprotection_google'] = $this->config->get('alfaprotection_google');
			} else {
				$data['alfaprotection_google'] = '';
			}

			//$data['help_error'] = $this->language->get('help_error');

			return $this->load->view('fraud/alfaprotection_info.tpl', $data);
		}
	}
}