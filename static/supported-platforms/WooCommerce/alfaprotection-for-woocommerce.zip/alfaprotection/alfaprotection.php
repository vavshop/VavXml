<?php
/*
Plugin Name: Alfa Protection
Plugin URI: https://alfaprotection.com
Description: Alfa Protection - is a real-time automated fraud prevention for e-Commerce
Version: 1.0
Author: Alfa Protection
Author URI: https://alfaprotection.com
*/
add_action('admin_menu', 'register_alfa_protection_admin_menu');

function apt_retrive_data($key, $id){
	return json_decode(wp_remote_post( 'https://alfaprotection.com/protect/api/get_info/', array(
		'body'    =>  (array(
				"secret"    => $key,
				"id" => $id))))['body']);
}

function apr_retrive_settings($key){
	return json_decode(wp_remote_post( 'https://alfaprotection.com/protect/api/get/rules/', array(
		'headers' =>  array('content-type' => 'application/json'),
		'body'    =>  json_encode(array(
				"secret"    => $key,
				"code_name" => "risk_score"))))['body']);
}
function apt_set_order_status($post_id,$status){
	$key = get_option('apt_key');
	$tx_id = get_post_meta($post_id, 'apt_id')[0];
	if (!$tx_id) return false;
	$r = json_decode(wp_remote_post( 'https://alfaprotection.com/protect/api/set/transaction/', array(
		'headers' =>  array('content-type' => 'application/json'),
		'body'    =>  json_encode(array(
				"secret"    => $key,
				"transaction_id" => $tx_id,
				"code_name" => 'status',
				"val" => $status))))['body']);
	//print_r($r);
	//die();
}
function apr_set_settings($key,$min_val,$max_val){
	return json_decode(wp_remote_post( 'https://alfaprotection.com/protect/api/set/rules/', array(
		'headers' =>  array('content-type' => 'application/json'),
		'body'    =>  json_encode(array(
				"secret"    => $key,
				"code_name" => "risk_score",
				"min_val" => $min_val,
				"max_val" => $max_val))))['body']);
}
function apr_send_order_info($key,$data){
	return json_decode(wp_remote_post( 'https://alfaprotection.com/protect/api/riskfactor', array(
		'headers' =>  array('content-type' => 'application/json'),
		'body'    =>  json_encode(array("secret"    => $key) + $data)
		))['body']);
}

function register_alfa_protection_admin_menu() {
    add_submenu_page( 'woocommerce', 'Alfa Protection Anti-Fraud', 'Alfa Protection Anti-Fraud', 'manage_options', 'alfa-protection-settings', 'alfa_protection_settings_callback' ); 
}
function alfa_protection_settings_callback() {
	if ($_POST['act']=='save_key'){
		update_option('apt_key',$_POST['apt_key']);
	}
	$apt_key = get_option('apt_key');
	if ($_POST['act']=='save_settings'){
		apr_set_settings($apt_key,$_POST['min_val'],$_POST['max_val']);
		update_option('apt_google_map_key',$_POST['apt_google_map_key']);
		update_option('apt_decline_status',$_POST['apt_decline_status']);
		update_option('apt_manual_status',$_POST['apt_manual_status']);
		update_option('apt_aprroved_status',$_POST['apt_aprroved_status']);
			
	}
	$settings = apr_retrive_settings($apt_key);
	require_once __DIR__.'/pages/alfa_protection_options.php';
}
if (get_option('apt_aprroved_status')==''){
	update_option('apt_aprroved_status', 'wc-processing');
}
if (get_option('apt_manual_status')==''){
	update_option('apt_manual_status', 'wc-on-hold');
}
if (get_option('apt_decline_status')==''){
	update_option('apt_decline_status', 'wc-cancelled');
}

add_action( 'template_redirect', 'wc_custom_redirect_after_purchase' ); 
function wc_custom_redirect_after_purchase() {
	global $wp;
	if ( is_checkout() && ! empty( $wp->query_vars['order-received'] ) ) {
		$order_id = $wp->query_vars['order-received'];
		$order_meta = get_post_meta($wp->query_vars['order-received']);
		$order = get_post($wp->query_vars['order-received']);
		$data = array (
				  'browser' => 
				  array (
				    "ip" =>  $_SERVER['REMOTE_ADDR'],
					"user_agent" => $_SERVER ['HTTP_USER_AGENT'],
					"language" => $_SERVER['HTTP_ACCEPT_LANGUAGE']
				  ),
				  'shop' => 
				  array (
				    "id"=> "wp",
					 "event" => "purchase",
					 "transaction" => $order_meta['_order_key'][0],
					 "datetime" => date("c", strtotime($order->post_date_gmt)),
				  ),
				  'user' => 
				  array (
				    "id" => $order_meta['_customer_user'][0],
					"name_md5" => md5($order_meta['_billing_first_name'][0] + ' ' + $order_meta['_billing_last_name'][0]),
					"email" => md5($order_meta['_billing_email'][0]),
					"domain" => substr(strrchr($order_meta['_billing_email'][0], "@"), 1)),
				  'billing' => 
				  array (
				     "first_name" => $order_meta['_billing_first_name'][0],
					  "last_name"=> $order_meta['_billing_last_name'][0],
					  "company"=>  $order_meta['_billing_company'][0],
					  "address"=> $order_meta['_billing_address_1'][0],
					  "address_2"=> $order_meta['_billing_address_2'][0],
					  "city"=> $order_meta['_billing_city'][0],
					  "region"=> $order_meta['_billing_state'][0],
					  "country"=> $order_meta['_billing_country'][0],
					  "postal"=> $order_meta['_billing_postcode'][0],
					  "phone"=> $order_meta['_billing_phone'][0],
				  ),
				  'selling' => 
				  array (
				     "first_name"=> $order_meta['_shipping_first_name'][0],
					 "last_name"=> $order_meta['_shipping_last_name'][0],
					 "company"=>  $order_meta['_shipping_company'][0],
					 "address"=> $order_meta['_shippingg_address_1'][0],
					 "address_2"=> $order_meta['_shipping_address_2'][0],
					 "city"=> $order_meta['_shipping_city'][0],
					 "region"=> $order_meta['_shipping_state'][0],
					 "country"=> $order_meta['_shipping_country'][0],
					 "postal"=> $order_meta['_shipping_postcode'][0],			
				  ),
				  'order' => 
				  array (
				    'amount' => $order_meta['_order_total'][0],
				    'order_id' => $order->ID,
				    'currency' => $order_meta['_order_currency'][0], 
				    'discount_code' => '',
				    'affiliate_id' => '',
				    'subaffiliate_id' => '',
				    'referrer_uri' => $_SERVER["HTTP_REFERER"],
				    'is_gift' => '',
				    'has_gift_message' => '',
				  ),
				  'user_id' => $order_meta['_customer_user'][0],
				);
		//
		//print_r($data);
		//die();
		if (get_post_meta($order_id,'apt_id')[0]) return;
		$res = apr_send_order_info(get_option('apt_key'), $data);
		update_post_meta($order_id, 'apt_id', $res->id);

		if ($res->status=='approved'){
			$order = new WC_Order($order_id);
			$order->update_status(get_option('apt_aprroved_status'), 'Approved by Alfaprotection'); 
		}

		if ($res->status=='manual_check'){
			$order = new WC_Order($order_id);
			$order->update_status(get_option('apt_manual_status'), 'Manual check by Alfaprotection'); 
		}
		if ($res->status=='decline'){
			$order = new WC_Order($order_id);
			$order->update_status(get_option('apt_decline_status'), 'Order declined by Alfaprotection'); 
		}

		//print_r($data);
	}
}

function add_manual_chech_to_order_statuses( $order_statuses ) {
    $new_order_statuses = array();
    // add new order status after processing
    foreach ( $order_statuses as $key => $status ) {
        $new_order_statuses[ $key ] = $status;
        if ( 'wc-manual-check' === $key ) {
            $new_order_statuses['wc-manual-check'] = 'Manual check';
        }
    }
    return $new_order_statuses;
}
add_filter( 'wc_order_statuses', 'add_manual_chech_to_order_statuses' );

//
//Adding Meta container admin shop_order pages
//
add_action( 'add_meta_boxes', 'mv_add_meta_boxes' );
if ( ! function_exists( 'mv_add_meta_boxes' ) )
{
    function mv_add_meta_boxes()
    {
        global $woocommerce, $order, $post;

        add_meta_box( 'mv_other_fields', __('Alfa Protection Anti-Fraud','woocommerce'), 'mv_add_other_fields_for_packaging', 'shop_order', 'advanced', 'core' );
    }
}

if ( ! function_exists( 'mv_save_wc_order_other_fields' ) )
{
    function mv_add_other_fields_for_packaging()
    {
    	require_once __DIR__.'/pages/alfa_protection_order_data.php';
    }
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'alfaprotection/apr', 'callback', array(
		'methods' => 'POST',
		'callback' => 'apr_callback',
	) );
} );
function apr_callback(){
	global $wpdb;
	$c = file_get_contents('php://input');
	//update_option('apr_last_callback','');
	$data = json_decode($c);
	if ($data->type != 'transaction_status')
		return;
	$posts = $wpdb->get_results("SELECT * FROM $wpdb->postmeta
		WHERE meta_key = 'apt_id' AND  meta_value = '$data->transaction' LIMIT 1", ARRAY_A);
	if ($data->value=='approved'){
		$order = new WC_Order($posts[0]['post_id']);
		$order->update_status(get_option('apt_aprroved_status'), 'Approved by Alfaprotection'); 
	}
	if ($data->value=='manual_check'){
		$order = new WC_Order($posts[0]['post_id']);
		$order->update_status(get_option('apt_manual_status'), 'Manual check by Alfaprotection'); 
	}
	if ($data->value=='decline'){
		$order = new WC_Order($posts[0]['post_id']);
		$order->update_status(get_option('apt_decline_status'), 'Order declined by Alfaprotection'); 
	}
	$c = $c."\n".get_option('apr_last_callback');
	update_option('apr_last_callback',$c);
	return array('ok'=>'ok', 'req' => file_get_contents('php://input'));
}
add_action( 'rest_api_init', function () {
	register_rest_route( 'alfaprotection/apr', 'callback', array(
		'methods' => 'GET, OPTIONS',
		'callback' => 'apr_callback_get',
	) );
} );
function apr_callback_get(){
	global $wpdb;
	echo get_option('apr_last_callback');
}

add_action( 'init', 'handle_preflight' );

function handle_preflight() {
    header("Access-Control-Allow-Origin: " . get_http_origin());
    header("Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE");
    header("Access-Control-Allow-Credentials: true");
    if ( 'OPTIONS' == $_SERVER['REQUEST_METHOD'] ) {
        status_header(200);
        exit();
    }
}

function apt_woocommerce_failed($order_id) {
    apt_set_order_status($order_id,'decline');
}
function apt_woocommerce_hold($order_id) {
    apt_set_order_status($order_id,'manual_check');
}
function apt_woocommerce_completed($order_id) {
   apt_set_order_status($order_id,'approved');
}
function apt_woocommerce_refunded($order_id) {
   apt_set_order_status($order_id,'decline');
}
function apt_woocommerce_cancelled($order_id) {
   apt_set_order_status($order_id,'decline');
}

add_action( 'woocommerce_order_status_failed', 'apt_woocommerce_failed', 10, 1);
add_action( 'woocommerce_order_status_on-hold', 'apt_woocommerce_hold', 10, 1);
add_action( 'woocommerce_order_status_completed', 'apt_woocommerce_completed', 10, 1);
add_action( 'woocommerce_order_status_refunded', 'apt_woocommerce_refunded', 10, 1);
add_action( 'woocommerce_order_status_cancelled', 'apt_woocommerce_cancelled', 10, 1);
