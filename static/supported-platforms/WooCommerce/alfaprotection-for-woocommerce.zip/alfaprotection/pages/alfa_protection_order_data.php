 <?php 
 	global $woocommerce, $order, $post;
 	$apt_id = get_post_meta($post->ID,'apt_id')[0];
 	$apt_key = get_option('apt_key');
 	if (!$apt_key){
 		echo "no data";
 		return;
 	}
 	$data = apt_retrive_data($apt_key, $apt_id);
 	if ($data->error){
 		echo "no data recived";
 		return;
 	}
 	function returnOrNA($str){
 		if ($str && $str!='') return $str;
 		return 'N/A';
 	}

?>
        <div class="box-header">
		<div class="table_top_rightside">
		</div>
	</div>
	<div class="row">
		<div class="col-md-4">
			<!-- begin Favorites block -->
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title">Favorites</h3>
				</div>
				<table class="table">
					<tbody>
						<tr>
							<td>Alfa Protection id</td>
							<td><?= $apt_id; ?></td>
						</tr>
						<tr>
							<td>Risk score</td>
							<td><?= $data->risk_score ?> </td>
						</tr>
						<tr>
							<td>Ip risk</td>
							<td><?= $data->ip_address->risk ?></td>
						</tr>
						<tr>
							<td>Organization</td>
							<td><?= $data->ip_address->traits->organization ?></td>
						</tr>
													<tr>
								<td>Text status messages</td>
								<td><?php foreach($data->status_messages as $status_messages){
											echo  $status_messages."<br>";
										} ?>
																		</td>
							</tr>
											</tbody>
				</table>
			</div>
			<!-- end Favorites block -->
		</div>
		<div class="col-md-8">
			<!-- begin Map block -->
			<div class="panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title">Map</h3>
				</div>
				<div id="map" style="height: 400px;"></div>
			</div>
			<!-- end Map block -->
		</div>
	</div>



	<div class='apr-container'>
		<div class='apt-block'>
			<div class="panel-heading">
				<h3 class="panel-title">Billing address</h3>
			</div>
			<table class="table">
				<tbody>
					<tr>
						<td>Distance to ip location</td>
						<td><?= $data->billing->distance_to_ip_location ?></td>
					</tr>
					<tr>
						<td>Is in ip country</td>
						<td><?= $data->billing->is_in_ip_country ?></td>
					</tr>
					<tr>
						<td>Is postal in city</td>
						<td><?= $data->billing->is_postal_in_city ?></td>
					</tr>
					<tr>
						<td>Latitude</td>
						<td><?= $data->billing->latitude ?></td>
					</tr>
					<tr>
						<td>Longitude</td>
						<td><?= $data->billing->longitude ?></td>
					</tr>
				</tbody>
			</table>	
		</div>

		<div class='apt-block'>
				<div class="panel-heading">
					<h3 class="panel-title">E-mail</h3>
				</div>
				<table class="table">
					<tbody>
						<tr>
							<td>Is free</td>
							<td><?= returnOrNA($data->email->is_free) ?></td>
						</tr>
						<tr>
							<td>Is high risk</td>
							<td><?= returnOrNA($data->email->is_high_risk) ?></td>
						</tr>
					</tbody>
				</table>
		</div>

		<div class='apt-block'>
			<div class="panel-heading">
					<h3 class="panel-title">Ip address</h3>
				</div>
			
						<table class="table">
								<tbody>
									<tr>
										<td>Ip risk</td>
										<td><?= $data->ip_address->risk ?></td>
									</tr>
								</tbody>
							</table>
							<table class="table">
								<tbody>
									<tr>
										<td>Queries remaining</td>
										<td><?= returnOrNA($data->queries_remaining) ?></td>
									</tr>
								</tbody>
							</table>

		</div>
		<div class='apt-block'>
			<div class="panel-heading">
				<h3 class="panel-title">City</h3>	
			</div>
								<table class="table">
									<tbody>
										<tr>
											<td>Confidence</td>
											<td><?= returnOrNA($data->ip_address->confidence) ?></td>
										</tr>
										<tr>
											<td>Geoname id</td>
											<td><?= returnOrNA($data->ip_address->geoname_id) ?></td>
										</tr>
										<tr>
											<td>Name</td>
											<td><?= returnOrNA($data->ip_address->city->name) ?></td>
										</tr>
										<tr>
											<td>Names</td>
											<td><?= returnOrNA($data->ip_address->city->names) ?></td>
										</tr>
									</tbody>
								</table>
		</div>

		<div class='apt-block'>
			<div class="panel-heading">
									<h3 class="panel-title">Location</h3>
								</div>
								<table class="table">
									<tbody>
										<tr>
											<td>Local time</td>
											<td><?= returnOrNA($data->ip_address->location->local_time) ?></td>
										</tr>
										<tr>
											<td>Average income</td>
											<td><?= returnOrNA($data->ip_address->location->average_income) ?></td>
										</tr>
										<tr>
											<td>Accuracy radius</td>
											<td><?= returnOrNA($data->ip_address->location->accuracy_radius) ?></td>
										</tr>
										<tr>
											<td>Latitude</td>
											<td><?= returnOrNA($data->ip_address->location->latitude) ?></td>
										</tr>
										<tr>
											<td>Longitude</td>
											<td><?= returnOrNA($data->ip_address->location->longitude) ?></td>
										</tr>
										<tr>
											<td>Metro code</td>
											<td><?= returnOrNA($data->ip_address->location->metro_code) ?></td>
										</tr>
										<tr>
											<td>Population density</td>
											<td><?= returnOrNA($data->ip_address->location->population_density) ?></td>
										</tr>
										<tr>
											<td>Time zone</td>
											<td><?= returnOrNA($data->ip_address->location->time_zone) ?></td>
										</tr>
									</tbody>
								</table>
		</div>

		<div class='apt-block'>
			<div class="panel-heading">
									<h3 class="panel-title">Continent</h3>
								</div>
								<table class="table">
									<tbody>
										<tr>
											<td>Code</td>
											<td><?= returnOrNA($data->ip_address->continent->code) ?></td>
										</tr>
										<tr>
											<td>Geoname id</td>
											<td><?= returnOrNA($data->ip_address->continent->geoname_id) ?></td>
										</tr>
										<tr>
											<td>Name</td>
											<td><?= returnOrNA($data->ip_address->continent->name) ?></td>
										</tr>
										<tr>
											<td>Names</td>
											<td><?= returnOrNA($data->ip_address->continent->names) ?></td>
										</tr>
									</tbody>
								</table>
		</div>

		<div class='apt-block'>
			<div class="panel-heading">
									<h3 class="panel-title">Registered country</h3>
								</div>
								<table class="table">
									<tbody>
										<tr>
											<td>Is high risk</td>
											<td><?= returnOrNA($data->ip_address->registered_country->is_high_risk) ?></td>
										</tr>
										<tr>
											<td>Confidence</td>
											<td><?= returnOrNA($data->ip_address->registered_country->confidence) ?></td>
										</tr>
										<tr>
											<td>Geoname id</td>
											<td><?= returnOrNA($data->ip_address->registered_country->geoname_id) ?></td>
										</tr>
										<tr>
											<td>Iso code</td>
											<td><?= returnOrNA($data->ip_address->registered_country->iso_code) ?></td>
										</tr>
										<tr>
											<td>Name</td>
											<td><?= returnOrNA($data->ip_address->registered_country->name) ?></td>
										</tr>
										<tr>
											<td>Names</td>
											<td><?= returnOrNA($data->ip_address->registered_country->names) ?></td>
										</tr>
									</tbody>
								</table>
		</div>
		<div class='apt-block'>
			<div class="panel-heading">
									<h3 class="panel-title">Country</h3>
								</div>
								<table class="table">
									<tbody>
										<tr>
											<td>Is high risk</td>
											<td><?= returnOrNA($data->ip_address->country->is_high_risk) ?></td>
										</tr>
										<tr>
											<td>Confidence</td>
											<td><?= returnOrNA($data->ip_address->country->confidence) ?></td>
										</tr>
										<tr>
											<td>Geoname id</td>
											<td><?= returnOrNA($data->ip_address->country->geoname_id) ?></td>
										</tr>
										<tr>
											<td>Iso code</td>
											<td><?= returnOrNA($data->ip_address->country->iso_code) ?></td>
										</tr>
										<tr>
											<td>Name</td>
											<td><?= returnOrNA($data->ip_address->country->name) ?></td>
										</tr>
										<tr>
											<td>Names</td>
											<td><?= returnOrNA($data->ip_address->country->names) ?></td>
										</tr>
									</tbody>
								</table>
		</div>

		<div class='apt-block'>
			<div class="panel-heading">
									<h3 class="panel-title">Subdivisions</h3>
								</div>
								<table class="table">
									<tbody>
										<tr>
											<td>Is high risk</td>
											<td><?= returnOrNA($data->ip_address->subdivisions->is_high_risk) ?></td>
										</tr>
										<tr>
											<td>Confidence</td>
											<td><?= returnOrNA($data->ip_address->subdivisions->confidence) ?></td>
										</tr>
										<tr>
											<td>Geoname id</td>
											<td><?= returnOrNA($data->ip_address->subdivisions->geoname_id) ?></td>
										</tr>
										<tr>
											<td>Iso code</td>
											<td><?= returnOrNA($data->ip_address->subdivisions->iso_code) ?></td>
										</tr>
										<tr>
											<td>Name</td>
											<td><?= returnOrNA($data->ip_address->subdivisions->name) ?></td>
										</tr>
										<tr>
											<td>Names</td>
											<td><?= returnOrNA($data->ip_address->subdivisions->names) ?></td>
										</tr>
									</tbody>
								</table>
		</div>
		<div class='apt-block'>
			<div class="panel-heading">
				<h3 class="panel-title">Traits</h3>
			</div>
							<table class="table">
								<tbody>
									<tr>
										<td>Names</td>
										<td><?= returnOrNA($data->ip_address->traits->organization) ?></td>
									</tr>
									<tr>
										<td>Autonomous system organization</td>
										<td><?= returnOrNA($data->ip_address->traits->autonomous_system_organization) ?></td>
									</tr>
									<tr>
										<td>Connection type</td>
										<td><?= returnOrNA($data->ip_address->traits->connection_type) ?></td>
									</tr>
									<tr>
										<td>Domain</td>
										<td><?= returnOrNA($data->ip_address->traits->domain) ?></td>
									</tr>
									<tr>
										<td>Ip address</td>
										<td><?= returnOrNA($data->ip_address->traits->ip_address) ?></td>
									</tr>
									<tr>
										<td>Is anonymous proxy</td>
										<td><?= returnOrNA($data->ip_address->traits->is_anonymous_proxy) ?></td>
									</tr>
									<tr>
										<td>Is legitimate proxy</td>
										<td><?= returnOrNA($data->ip_address->traits->is_legitimate_proxy) ?></td>
									</tr>
									<tr>
										<td>Is satellite provider</td>
										<td><?= returnOrNA($data->ip_address->traits->is_satellite_provider) ?></td>
									</tr>
									<tr>
										<td>Isp</td>
										<td><?= returnOrNA($data->ip_address->traits->isp) ?></td>
									</tr>
									<tr>
										<td>Organization</td>
										<td><?= returnOrNA($data->ip_address->traits->organization) ?></td>
									</tr>
									<tr>
										<td>Connection type</td>
										<td><?= returnOrNA($data->ip_address->traits->user_type) ?></td>
									</tr>
								</tbody>
							</table>
		
		</div>
			
	</div>
</div>
<style>
	.apt-block {
	    display: inline-block;
	    width: 220px;
	    padding: 20px;
	}
</style>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=<?= get_option('apt_google_map_key') ?>"></script>
<script type="text/javascript">
	var map = null,
		markers = [
		['Location', <?= $data->ip_address->location->latitude ?>, <?= $data->ip_address->location->longitude ?>],
		['Billing address', <?= $data->billing->latitude ?>, <?= $data->billing->longitude ?>],
		//['Shipping address', 40.108126500, -8.509300600],
	];

	function mapInit() {
		map = new google.maps.Map(document.getElementById('map'), {
			zoom: 4,
	  		center: {
	  			lat: 50.433300000,
	  			lng: 30.516700000	  		}
	  	});

	  	var markersBounds = new google.maps.LatLngBounds();

		for (var i = 0; i < markers.length; i++) {
			var markerPosition = new google.maps.LatLng(markers[i][1], markers[i][2]);

		    markersBounds.extend(markerPosition);

			var marker = new google.maps.Marker({
			    position: markerPosition,
			    map: map,
			    label: markers[i][0]
			});
		}

		map.setCenter(markersBounds.getCenter(), map.fitBounds(markersBounds));
	}
	mapInit();
</script>