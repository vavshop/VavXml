<h3>Alfa Protection settings</h3>
<?php if ($settings->error){?>
<div class="error notice">
    <p>Alfa Protection License Key invalid. If you don't have a license key you can get it on alfaprotection.com
</div>
<?php } ?>
<div class="card">
<table class="form-table">
<tbody><tr>
<form method='post' action=''>
<input type='hidden' name='act' value='save_key'>
<th scope="row"><label for="blogname">Alfa Protection License Key <a href="#" title="A license key can be obtained from AlfaProtection.com
   This module will not work without a license key">(?)</a></label></th>
<td><input name="apt_key" type="text" value="<?= $apt_key ?>" class="regular-text"> <?php submit_button( 'Save key' ); ?></td>
</form>
</tr>
</tbody></table>
</div>

<div class="card">

<h3 >Alfaprotection callback URL<a href="#" title="To synchronize order statuses with the Alpha Protection dashboard you need to save this URL by going to the Alpha Protection site in the API > Callback URL section.">(?)</a></h3><br>
<input readonly=""  type="text" value="<?= get_site_url(); ?>/wp-json/alfaprotection/apr/callback" class="regular-text" style="
    width: 100%;
    background-color: whitesmoke;
"> 
<br><br>
</div>

<?php if (!$settings->error){?>
<div class='card'>
<table class="form-table">
<tbody>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<form method='post' action=''>
<input type='hidden' name='act' value='save_settings'>
	<tr>
		<th scope="row"><label for="min_val">Limit approved <a href="#" title="All orders that will receive Risk Score less than the specified number will be approved. All that more will receive a Manual Check. Or another value that you will choose.">(?)</a></label></th>
		<td><input name="min_val" type="text" value="<?= $settings->min_val ?>" class="regular-text"></td>
	</tr>
	<tr>
		<th scope="row"><label for="apt_aprroved_status">Approved order status</label></th>
		<td>
			<select type='select' name='apt_aprroved_status'> 
				<?php $statuses = wc_get_order_statuses(); 
				//echo "<option value='-1'>default</option>";
				foreach($statuses as $status_code => $value){
					echo "<option value='$status_code' ".selected( $status_code, get_option('apt_aprroved_status') , false).">$value</option>";
				}
				?>
			</select>
		</td>
	</tr>

	<tr>
		<th scope="row"><label for="max_val">Limit manual <br>check <a href="#" title="Averything that is more than the specified value will be automatically Declined">(?)</a></label></th>
		<td><input name="max_val" type="text" value="<?= $settings->max_val ?>" class="regular-text"> </td>
	</tr>
	<tr>
		<th scope="row"><label for="apt_manual_status">Manual check order status</label></th>
		<td>
			<select type='select' name='apt_manual_status'> 
				<?php $statuses = wc_get_order_statuses(); 
				//echo "<option value='-1'>default</option>";
				foreach($statuses as $status_code => $value){
					echo "<option value='$status_code' ".selected( $status_code, get_option('apt_manual_status') , false).">$value</option>";
				}
				?>
			</select>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="apt_decline_status">Decline status</label></th>
		<td>
			<select type='select' name='apt_decline_status'> 
				<?php $statuses = wc_get_order_statuses(); 
				//echo "<option value='-1'>default</option>";
				foreach($statuses as $status_code => $value){
					echo "<option value='$status_code' ".selected( $status_code, get_option('apt_decline_status') , false).">$value</option>";
				}
				?>
			</select>
		</td>
	</tr>
	<tr>
		<th scope="row"><label for="blogname">AGoogle Map API key <a href="#" title="This key is needed to display the Google Map in the details of the order">(?)</a></label></th>
		<td><input name="apt_google_map_key" type="text" value="<?= get_option('apt_google_map_key') ?>" class="regular-text"></td>
	</tr>
	<tr><th scope="row"></th><td><?php submit_button( 'Save settings' ); ?></td></tr>
</form>
</tbody></table>
</div>
<script type="text/javascript">
jQuery( function() {
    jQuery( document ).tooltip();
  } );
</script>
<?php }